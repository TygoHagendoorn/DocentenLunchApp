package com.example.mobileappsexamen;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SQLiteDatabase docentDB = this.openOrCreateDatabase("docentDB", MODE_PRIVATE, null);

        File dbFile = getDatabasePath("docentDB");
        if (dbFile.exists()) {
            Log.i("database docentDB", "Database bestaat al!");
        } else {
            Log.i("database docentDB", "Database bestaat niet!");
        }

        docentDB.execSQL("CREATE TABLE IF NOT EXISTS "
                + "bestelling"
                + "(productnaam VARCHAR NOT NULL, besteltijd TIMESTAMP NOT NULL);");

    }
}