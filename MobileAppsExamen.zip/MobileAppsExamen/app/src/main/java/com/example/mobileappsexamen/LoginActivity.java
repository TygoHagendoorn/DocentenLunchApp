package com.example.mobileappsexamen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.File;


public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SQLiteDatabase docentDB = this.openOrCreateDatabase("docentDB", MODE_PRIVATE, null);

        File dbFile = getDatabasePath("docentDB");
        if (dbFile.exists()) {
            Log.i("database docentDB", "Database bestaat al!");
        } else {
            Log.i("database docentDB", "Database bestaat niet!");
        }

        docentDB.execSQL("CREATE TABLE IF NOT EXISTS "
                + "gegevens"
                + "(Voornaam VARCHAR NOT NULL, Tussenvoegsel VARCHAR, Achternaam VARCHAR NOT NULL);");

        /*Cursor c = docentDB.rawQuery("select * from "
                + "gegevens", null);
        int Column1 = c.getColumnIndex("Voornaam");
        int Column2 = c.getColumnIndex("Tussenvoegsel");
        int Column3 = c.getColumnIndex("Achternaam");
        c.moveToFirst();
        String Voornaam = c.getString(Column1);
        String Tussenvoegsel = c.getString(Column2);
        String Achternaam = c.getString(Column3);
        Log.i(Voornaam, Tussenvoegsel);*/
    }

    public void onClick(View view) {
        SQLiteDatabase docentenDB = this.openOrCreateDatabase("docentenDB", MODE_PRIVATE, null);

        EditText etVoornaam = (EditText) findViewById(R.id.firstname);
        EditText etTussenvoegsel = (EditText) findViewById(R.id.midname);
        EditText etAchternaam = (EditText) findViewById(R.id.lastname);

        String voornaam = etVoornaam.getText().toString();
        String tussenvoegsel = etTussenvoegsel.getText().toString();
        String Achternaam = etAchternaam.getText().toString();

            switch (view.getId()) {
                case R.id.register:
                    Log.i("Registreren", "Gelukt");
                    String sql =
                            "INSERT INTO gegevens (voornaam, Tussenvoegsel, Achternaam) VALUES ('" + voornaam + "', '" + tussenvoegsel + "', '" + Achternaam + "')";
                    docentenDB.execSQL(sql);
                    break;

                case R.id.login:
                    String table = "gegevens";
                    String[] columnsToReturn = {"Achternaam"};
                    String selection = "Voornaam =?";
                    String[] selectionArgs = {voornaam};

                    try {
                        Cursor cursor = docentenDB.query(table, columnsToReturn, selection, selectionArgs,
                                null, null, null);

                        cursor.moveToLast();
                        String column1 = cursor.getString(0);
                        if (column1.equals(Achternaam)) {
                            Log.d(column1, "Inloggen gelukt!");
                            Intent I = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(I);
                        } else {
                            Log.d(column1, "Inloggen niet gelukt!");
                        }
                        cursor.close();
                        break;
                    } catch (CursorIndexOutOfBoundsException e) {
                        Log.d(voornaam, "Account niet gevonden!");
                    }
            }
        }
    }

